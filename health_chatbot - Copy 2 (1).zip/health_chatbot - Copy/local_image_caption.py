"""
Offline image captioning (no API keys). Uses BLIP via Hugging Face transformers.
First run downloads model weights (~1 GB) — then works fully local.
Set LOCAL_BLIP_DISABLE=1 to turn off. BLIP_MODEL_ID overrides default model.
"""
import io
import os
from typing import Optional

_pipeline = None


def caption_image_bytes(image_bytes: bytes, max_edge: int = 384) -> Optional[str]:
    """
    Return a short English caption, or None if disabled / deps missing / error.
    """
    if os.environ.get("LOCAL_BLIP_DISABLE", "").strip().lower() in ("1", "true", "yes"):
        return None
    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        from transformers import pipeline
    except ImportError:
        return None

    global _pipeline
    try:
        if _pipeline is None:
            model_id = os.environ.get(
                "BLIP_MODEL_ID", "Salesforce/blip-image-captioning-base"
            ).strip()
            _pipeline = pipeline(
                "image-to-text",
                model=model_id,
            )
        im = Image.open(io.BytesIO(image_bytes))
        im = im.convert("RGB")
        im.thumbnail((max_edge, max_edge))
        out = _pipeline(im, max_new_tokens=50)
        if not out:
            return None
        text = (out[0].get("generated_text") or "").strip()
        return text or None
    except Exception:
        return None
