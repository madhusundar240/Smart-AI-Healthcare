import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

from season_context import apply_season_to_predictions, SEASON_DISEASE_WEIGHTS

_BASE = os.path.dirname(os.path.abspath(__file__))
_DATA_CSV = os.path.join(_BASE, "data", "symptoms_dataset.csv")
_MODEL_DIR = os.path.join(_BASE, "models")

SEVERITY_MAP = {
    "mild": {
        "label": "Mild",
        "action": "Rest at home, drink fluids, monitor symptoms. Visit a doctor if no improvement in 3 days.",
        "color": "green",
        "emoji": "🟢",
    },
    "moderate": {
        "label": "Moderate",
        "action": "Visit a clinic within 24-48 hours. Do not ignore these symptoms.",
        "color": "orange",
        "emoji": "🟡",
    },
    "severe": {
        "label": "Severe",
        "action": "Seek immediate medical attention! Go to a hospital now.",
        "color": "red",
        "emoji": "🔴",
    },
}

_MODEL_BUNDLE = None
_TRAINING_DF = None

# When few symptoms are known, the RF sees an almost-empty vector and picks noisy classes.
# We instead rank diseases by training rows that match all user symptoms (with synonym families),
# then break ties with a sensible clinical ordering for common nonspecific presentations.
SYMPTOM_FAMILIES = (
    {"fever", "mild_fever", "high_fever"},
    {"cough", "dry_cough", "persistent_cough", "severe_cough", "whooping_sound"},
    {"headache", "severe_headache", "throbbing_headache"},
    {"body_ache", "muscle_pain", "muscle_ache", "muscle_aches"},
    {"breathing_difficulty", "shortness_of_breath", "rapid_breathing", "wheezing"},
)

NONSPECIFIC_DISEASE_PRIORITY = [
    "Common Cold",
    "Flu",
    "COVID-19",
    "Sinusitis",
    "Migraine",
    "Gastritis",
    "Food Poisoning",
    "Typhoid",
    "Dengue",
    "Malaria",
    "Chikungunya",
    "Pneumonia",
    "Chickenpox",
    "Measles",
    "Hand Foot Mouth Disease",
    "Mumps",
    "Urinary Tract Infection",
    "Tuberculosis",
    "Whooping Cough",
    "Leptospirosis",
    "Appendicitis",
    "Cholera",
    "Heat Stroke",
    "Jaundice",
]

SEVERITY_TRIGGER_SYMPTOMS = {
    "chest_pain",
    "breathing_difficulty",
    "shortness_of_breath",
    "blood_in_cough",
    "severe_headache",
    "severe_abdominal_pain",
    "confusion",
    "fainting",
    "bleeding",
    "severe_diarrhea",
    "rapid_breathing",
    "wheezing",
}

GENERIC_MILD_SYMPTOMS = {
    "fever",
    "mild_fever",
    "headache",
    "cough",
    "dry_cough",
    "fatigue",
    "tiredness",
    "runny_nose",
    "sneezing",
    "sore_throat",
    "body_ache",
    "chills",
    "cold",
    "congestion",
    "nausea",
    "dizziness",
}


def _families_for(symptom):
    for fam in SYMPTOM_FAMILIES:
        if symptom in fam:
            return fam
    return {symptom}


def _row_symptom_set(row, sym_cols):
    return {
        str(row[c]).strip()
        for c in sym_cols
        if pd.notna(row[c]) and str(row[c]).strip()
    }


def _row_matches_user_symptoms(row_syms, user_symptoms):
    for u in user_symptoms:
        need = _families_for(u)
        if not (row_syms & need):
            return False
    return True


def _training_df():
    global _TRAINING_DF
    if _TRAINING_DF is None:
        _TRAINING_DF = pd.read_csv(_DATA_CSV)
    return _TRAINING_DF


def _disease_priority_index(name):
    try:
        return NONSPECIFIC_DISEASE_PRIORITY.index(name)
    except ValueError:
        return len(NONSPECIFIC_DISEASE_PRIORITY)


FEVER_FAMILY = {"fever", "mild_fever", "high_fever"}


def _predict_low_information(symptoms_list, season=None):
    """Rank diseases from training rows that contain all user symptoms (family-aware)."""
    df = _training_df()
    sym_cols = ["symptom1", "symptom2", "symptom3", "symptom4", "symptom5"]
    counts = {}
    for _, row in df.iterrows():
        rs = _row_symptom_set(row, sym_cols)
        if not _row_matches_user_symptoms(rs, symptoms_list):
            continue
        d = row["disease"]
        counts[d] = counts.get(d, 0) + 1
    if not counts:
        return None

    def pack(diseases):
        diseases = [d for d in diseases if d in counts][:3]
        if len(diseases) < 3:
            return None
        total = sum(counts[d] for d in diseases)
        return [
            {"disease": d, "probability": max(round(100.0 * counts[d] / total, 1), 5.0) if total else 33.3}
            for d in diseases
        ]

    # Isolated "fever" is matched by many rows with the same count; prefer common viral causes first.
    if symptoms_list and all(s in FEVER_FAMILY for s in symptoms_list):
        viral_first = [d for d in NONSPECIFIC_DISEASE_PRIORITY if counts.get(d, 0) >= 1]
        if season:
            wmap = SEASON_DISEASE_WEIGHTS.get(season, {})
            viral_first.sort(
                key=lambda d: (-counts[d] * float(wmap.get(d, 1.0)), _disease_priority_index(d))
            )
        got = pack(viral_first)
        if got:
            return got

    max_c = max(counts.values())
    tied = [d for d, c in counts.items() if c == max_c]
    tied.sort(key=lambda d: (_disease_priority_index(d), d))
    top_three = tied[:3]
    total = sum(counts[d] for d in top_three)
    results = []
    for d in top_three:
        pct = round(100.0 * counts[d] / total, 1) if total else 0.0
        results.append({"disease": d, "probability": max(pct, 5.0)})
    return apply_season_to_predictions(results, season)


def _heuristic_severity(symptoms_list):
    """For 1–2 symptoms, avoid RF 'severe' on an almost-empty feature vector."""
    if not symptoms_list or len(symptoms_list) > 2:
        return None
    if any(s in SEVERITY_TRIGGER_SYMPTOMS for s in symptoms_list):
        return SEVERITY_MAP["severe"]
    if "high_fever" in symptoms_list:
        return SEVERITY_MAP["moderate"]
    if all(s in GENERIC_MILD_SYMPTOMS for s in symptoms_list):
        return SEVERITY_MAP["mild"]
    return SEVERITY_MAP["moderate"]


def _model_paths():
    os.makedirs(_MODEL_DIR, exist_ok=True)
    return {
        "disease": os.path.join(_MODEL_DIR, "disease_model.pkl"),
        "labels": os.path.join(_MODEL_DIR, "label_encoder.pkl"),
        "severity": os.path.join(_MODEL_DIR, "severity_model.pkl"),
        "symptoms": os.path.join(_MODEL_DIR, "symptoms_list.pkl"),
    }


def train_model():
    df = pd.read_csv(_DATA_CSV)
    sym_cols = ["symptom1", "symptom2", "symptom3", "symptom4", "symptom5"]
    all_symptoms = set()
    for col in sym_cols:
        all_symptoms.update(df[col].dropna().astype(str).str.strip().unique())
    all_symptoms = sorted(all_symptoms)
    X = pd.DataFrame(0, index=df.index, columns=all_symptoms, dtype=np.int8)
    for idx in df.index:
        present = {
            str(df.at[idx, c]).strip()
            for c in sym_cols
            if pd.notna(df.at[idx, c]) and str(df.at[idx, c]).strip()
        }
        for s in present:
            if s in X.columns:
                X.at[idx, s] = 1
    y = df["disease"]
    severity_y = df["severity"]
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X, y_encoded)
    severity_model = RandomForestClassifier(n_estimators=100, random_state=42)
    severity_model.fit(X, severity_y)
    paths = _model_paths()
    joblib.dump(model, paths["disease"])
    joblib.dump(le, paths["labels"])
    joblib.dump(severity_model, paths["severity"])
    joblib.dump(all_symptoms, paths["symptoms"])
    print(f"✅ Model trained! {len(le.classes_)} diseases, {len(all_symptoms)} symptoms.")
    print(f"Diseases: {list(le.classes_)}")


def _load_model_bundle():
    paths = _model_paths()
    try:
        return (
            joblib.load(paths["disease"]),
            joblib.load(paths["labels"]),
            joblib.load(paths["severity"]),
            joblib.load(paths["symptoms"]),
        )
    except Exception as exc:
        # Common cause: pickles built with another NumPy / scikit-learn version
        print(f"⚠️ Could not load saved models ({exc!r}). Re-training from {_DATA_CSV} …")
        train_model()
        return (
            joblib.load(paths["disease"]),
            joblib.load(paths["labels"]),
            joblib.load(paths["severity"]),
            joblib.load(paths["symptoms"]),
        )


def _get_models():
    global _MODEL_BUNDLE
    if _MODEL_BUNDLE is None:
        _MODEL_BUNDLE = _load_model_bundle()
    return _MODEL_BUNDLE


def predict_disease(symptoms_list, season=None):
    """
    With 1–2 symptoms, the random forest input is too sparse; we rank diseases from
    training rows that match all given symptoms (fever / cough families grouped).
    Severity uses simple rules for these low-information cases.

    ``season`` is optional: winter | summer | monsoon | spring | autumn | unknown | None
    """
    LOW_INFO_MAX = 2
    symptoms_list = list(symptoms_list or [])
    low = len(symptoms_list) <= LOW_INFO_MAX
    heur_sev = _heuristic_severity(symptoms_list) if low else None

    if low:
        alt = _predict_low_information(symptoms_list, season=season)
        if alt:
            return alt, heur_sev or SEVERITY_MAP["mild"]

    model, le, severity_model, all_symptoms = _get_models()
    input_vector = [1 if s in symptoms_list else 0 for s in all_symptoms]
    input_df = pd.DataFrame([input_vector], columns=all_symptoms)
    probs = model.predict_proba(input_df)[0]
    top3_idx = np.argsort(probs)[-3:][::-1]
    results = []
    for idx in top3_idx:
        disease = le.classes_[idx]
        probability = round(float(probs[idx]) * 100, 1)
        if probability > 3:
            results.append({"disease": disease, "probability": probability})
    severity_pred = severity_model.predict(input_df)[0]
    severity_info = SEVERITY_MAP.get(severity_pred, SEVERITY_MAP["moderate"])
    if heur_sev is not None:
        severity_info = heur_sev
    results = apply_season_to_predictions(results, season)
    return results, severity_info


if __name__ == "__main__":
    train_model()
