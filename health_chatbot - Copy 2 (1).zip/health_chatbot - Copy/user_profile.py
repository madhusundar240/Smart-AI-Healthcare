import json
import os

PROFILES_FILE = 'data/user_profiles.json'

def load_profiles():
    if os.path.exists(PROFILES_FILE):
        with open(PROFILES_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_profile(session_id, profile_data):
    profiles = load_profiles()
    profiles[session_id] = profile_data
    os.makedirs('data', exist_ok=True)
    with open(PROFILES_FILE, 'w') as f:
        json.dump(profiles, f)

def get_profile(session_id):
    profiles = load_profiles()
    return profiles.get(session_id, {})

def create_profile(session_id, name, age, gender, existing_conditions=None):
    profile = {
        "name": name,
        "age": int(age),
        "gender": gender,
        "existing_conditions": existing_conditions or [],
        "consultation_history": []
    }
    save_profile(session_id, profile)
    return profile

def add_consultation(session_id, symptoms, diseases, severity):
    profiles = load_profiles()
    if session_id in profiles:
        profiles[session_id]["consultation_history"].append({
            "symptoms": symptoms,
            "predicted_diseases": diseases,
            "severity": severity
        })
        with open(PROFILES_FILE, 'w') as f:
            json.dump(profiles, f)