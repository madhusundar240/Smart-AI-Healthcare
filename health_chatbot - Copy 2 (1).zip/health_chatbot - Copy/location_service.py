import os
import requests

GOOGLE_MAPS_API_KEY = os.environ.get("GOOGLE_MAPS_API_KEY", "your-google-maps-api-key")


def _format_listing(title, items):
    lines = [title]
    for i, h in enumerate(items[:5], 1):
        status = "🟢 Open" if h.get("open") else "🔴 Closed"
        lines.append(
            f"{i}. {h['name']}\n   📍 {h['address']}\n   {status} | ⭐ {h['rating']}\n"
        )
    return "\n".join(lines)


def search_places(lat, lng, place_type):
    url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    params = {
        "location": f"{lat},{lng}",
        "radius": 5000,
        "type": place_type,
        "key": GOOGLE_MAPS_API_KEY,
    }
    resp = requests.get(url, params=params, timeout=8).json()
    results = []
    for place in resp.get("results", [])[:8]:
        loc = (place.get("geometry") or {}).get("location") or {}
        results.append(
            {
                "name": place.get("name", "Unknown"),
                "address": place.get("vicinity", "Address not available"),
                "rating": place.get("rating", "N/A"),
                "open": place.get("opening_hours", {}).get("open_now", False),
                "lat": loc.get("lat"),
                "lng": loc.get("lng"),
                "place_id": place.get("place_id"),
            }
        )
    return results


def get_nearby_places_detail(location, use_coords=False):
    """
    Returns dict: text (markdown), center {lat,lng}, hospitals[], pharmacies[].
    On API failure, markers may be empty but text still has helpline info.
    """
    try:
        if use_coords:
            lat, lng = [float(x) for x in str(location).split(",")]
        else:
            geo_url = f"https://maps.googleapis.com/maps/api/geocode/json?address={location}&key={GOOGLE_MAPS_API_KEY}"
            geo_resp = requests.get(geo_url, timeout=8).json()
            if geo_resp.get("status") != "OK" or not geo_resp.get("results"):
                t = get_fallback_response(location)
                return {"text": t, "center": None, "hospitals": [], "pharmacies": []}
            loc = geo_resp["results"][0]["geometry"]["location"]
            lat, lng = loc["lat"], loc["lng"]

        hospitals = search_places(lat, lng, "hospital")
        pharmacies = search_places(lat, lng, "pharmacy")

        response = "📍 Nearby medical facilities:\n\n"
        response += _format_listing("🏥 HOSPITALS:", hospitals) + "\n\n"
        response += _format_listing("💊 PHARMACIES:", pharmacies)
        response += "\n\n🚨 EMERGENCY: Call 108 (Ambulance) | 102 (Medical Helpline)"

        return {
            "text": response,
            "center": {"lat": lat, "lng": lng},
            "hospitals": hospitals,
            "pharmacies": pharmacies,
        }
    except Exception:
        t = get_fallback_response(location)
        return {"text": t, "center": None, "hospitals": [], "pharmacies": []}


def get_nearby_places(location, use_coords=False):
    return get_nearby_places_detail(location, use_coords=use_coords)["text"]


def get_fallback_response(location):
    return f"""📍 Location Services for: {location}

🏥 EMERGENCY NUMBERS (India):
- 🚑 Ambulance: 108
- 🏥 Medical Helpline: 102  
- 👮 Police: 100
- 🔥 Fire: 101
- 📞 National Health Helpline: 1800-180-1104

💡 To find hospitals near you:
- Search "{location} government hospital" on Google Maps
- Or call 108 for emergency ambulance service

⚠️ For emergencies, call 108 immediately!"""
