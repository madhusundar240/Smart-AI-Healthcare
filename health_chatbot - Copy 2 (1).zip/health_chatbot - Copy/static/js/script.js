(function () {
  "use strict";

  const messagesEl = document.getElementById("messages");
  const typingEl = document.getElementById("typing");
  const inputEl = document.getElementById("messageInput");
  const sendBtn = document.getElementById("sendBtn");
  const resetBtn = document.getElementById("resetBtn");
  const voiceBtn = document.getElementById("voiceBtn");
  const imageInput = document.getElementById("imageInput");
  const imageBtn = document.getElementById("imageBtn");
  const analyzeImageBtn = document.getElementById("analyzeImageBtn");
  const imagePreview = document.getElementById("imagePreview");
  const langSelect = document.getElementById("langSelect");
  const seasonSelect = document.getElementById("seasonSelect");
  const locateBtn = document.getElementById("locateBtn");
  const downloadReport = document.getElementById("downloadReport");

  let map = null;
  let userMarker = null;
  let placeLayer = null;
  let lastStep = "symptoms";

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  function appendMessage(role, text) {
    const row = document.createElement("div");
    row.className = "msg-row msg-row--" + (role === "user" ? "user" : "bot");
    if (role === "user") {
      const bubble = document.createElement("div");
      bubble.className = "msg msg--user";
      bubble.innerHTML = escapeHtml(text);
      row.appendChild(bubble);
    } else {
      const av = document.createElement("div");
      av.className = "msg-avatar";
      av.setAttribute("aria-hidden", "true");
      av.textContent = "🌿";
      const bubble = document.createElement("div");
      bubble.className = "msg msg--bot";
      bubble.innerHTML = escapeHtml(text);
      row.appendChild(av);
      row.appendChild(bubble);
    }
    messagesEl.appendChild(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function setTyping(t) {
    if (!typingEl) return;
    if (!t) {
      typingEl.innerHTML = "";
      return;
    }
    typingEl.innerHTML =
      '<span class="typing-label">' +
      escapeHtml(t) +
      '</span><span class="typing-dots" aria-hidden="true"><span></span><span></span><span></span></span>';
  }

  function ensureMap(lat, lng) {
    if (!window.L) return;
    if (!map) {
      map = L.map("map", { zoomControl: true }).setView([lat, lng], 13);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap",
      }).addTo(map);
      placeLayer = L.layerGroup().addTo(map);
    } else {
      map.setView([lat, lng], 13);
    }
    if (!userMarker) {
      userMarker = L.marker([lat, lng]).addTo(map).bindPopup("You are here");
    } else {
      userMarker.setLatLng([lat, lng]);
    }
  }

  function clearPlaceMarkers() {
    if (placeLayer) placeLayer.clearLayers();
  }

  function addPlaceMarkers(items, color) {
    if (!map || !placeLayer || !items) return;
    items.forEach((p) => {
      if (p.lat == null || p.lng == null) return;
      L.circleMarker([p.lat, p.lng], {
        radius: 8,
        color,
        fillColor: color,
        fillOpacity: 0.35,
      })
        .bindPopup(escapeHtml(p.name || "") + "<br/><small>" + escapeHtml(p.address || "") + "</small>")
        .addTo(placeLayer);
    });
  }

  function applyMapPayload(mapData) {
    if (!mapData || !mapData.center) return;
    const c = mapData.center;
    ensureMap(c.lat, c.lng);
    clearPlaceMarkers();
    addPlaceMarkers(mapData.hospitals, "#38bdf8");
    addPlaceMarkers(mapData.pharmacies, "#a78bfa");
  }

  async function postJson(url, body) {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.response || r.statusText);
    return data;
  }

  async function handleChatResponse(data) {
    if (data && data.step) lastStep = data.step;
    if (data.response) appendMessage("bot", data.response);
    if (data.map) applyMapPayload(data.map);
    if (data.report_ready && downloadReport) {
      downloadReport.classList.remove("hidden");
    }
  }

  function buildChatPayload(messageText) {
    const payload = { message: messageText };
    if (seasonSelect && seasonSelect.value !== "auto") {
      payload.season = seasonSelect.value;
    }
    return payload;
  }

  async function sendMessage() {
    let trimmed = inputEl.value.trim();
    const sv = seasonSelect ? seasonSelect.value : "auto";
    if (!trimmed && lastStep === "season" && sv !== "auto") {
      trimmed = sv;
    }
    if (!trimmed) return;

    const display =
      inputEl.value.trim() ||
      (lastStep === "season" && sv !== "auto"
        ? seasonSelect.options[seasonSelect.selectedIndex].text
        : trimmed);
    appendMessage("user", display);
    inputEl.value = "";
    setTyping("Thinking…");
    sendBtn.disabled = true;
    try {
      const data = await postJson("/chat", buildChatPayload(trimmed));
      await handleChatResponse(data);
    } catch (e) {
      appendMessage("bot", "Something went wrong: " + e.message);
    } finally {
      setTyping("");
      sendBtn.disabled = false;
    }
  }

  async function uploadImage(file) {
    if (!file) return;
    setTyping("Analyzing image…");
    if (analyzeImageBtn) analyzeImageBtn.disabled = true;
    const fd = new FormData();
    fd.append("image", file);
    if (seasonSelect && seasonSelect.value !== "auto") {
      fd.append("season", seasonSelect.value);
    }
    try {
      const r = await fetch("/analyze_image", { method: "POST", body: fd });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.response || r.statusText);
      appendMessage("user", "[Uploaded image: " + file.name + "]");
      await handleChatResponse(data);
    } catch (e) {
      appendMessage("bot", "Image upload failed: " + e.message);
    } finally {
      setTyping("");
      if (imageInput) imageInput.value = "";
      if (imagePreview) imagePreview.style.display = "none";
      if (analyzeImageBtn) analyzeImageBtn.disabled = true;
    }
  }

  sendBtn.addEventListener("click", () => sendMessage());
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  resetBtn.addEventListener("click", async () => {
    await fetch("/reset");
    messagesEl.innerHTML = "";
    if (downloadReport) downloadReport.classList.add("hidden");
    lastStep = "symptoms";
    if (seasonSelect) seasonSelect.value = "auto";
    if (langSelect) langSelect.value = "en-US";
    if (analyzeImageBtn) analyzeImageBtn.disabled = true;
    if (imageInput) imageInput.value = "";
    if (imagePreview) {
      imagePreview.removeAttribute("src");
      imagePreview.style.display = "none";
    }
    await initChat();
  });

  if (imageBtn && imageInput) {
    imageBtn.addEventListener("click", () => imageInput.click());
  }
  if (imageInput) {
    imageInput.addEventListener("change", () => {
      const f = imageInput.files && imageInput.files[0];
      if (!f) {
        if (analyzeImageBtn) analyzeImageBtn.disabled = true;
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (imagePreview) {
          imagePreview.src = reader.result;
          imagePreview.style.display = "block";
        }
      };
      reader.readAsDataURL(f);
      if (analyzeImageBtn) analyzeImageBtn.disabled = false;
    });
  }
  if (analyzeImageBtn && imageInput) {
    analyzeImageBtn.addEventListener("click", () => {
      const f = imageInput.files && imageInput.files[0];
      if (f) uploadImage(f);
    });
  }

  /* ---------- Web Speech API ---------- */
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;

  function setupRecognition() {
    if (!voiceBtn) return;
    if (!SpeechRecognition) {
      voiceBtn.disabled = true;
      voiceBtn.title = "Speech recognition not supported in this browser";
      return;
    }
    recognition = new SpeechRecognition();
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.lang = (langSelect && langSelect.value) || "en-US";
    recognition.onresult = (ev) => {
      const t = ev.results[0][0].transcript;
      inputEl.value = (inputEl.value + " " + t).trim();
    };
    recognition.onerror = () => setTyping("");
    recognition.onend = () => {
      listening = false;
      voiceBtn.textContent = "🎤 Speak";
      setTyping("");
    };
  }

  if (langSelect) {
    langSelect.addEventListener("change", () => {
      if (recognition) recognition.lang = (langSelect && langSelect.value) || "en-US";
    });
  }

  if (voiceBtn) {
    voiceBtn.addEventListener("click", () => {
      if (!recognition) return;
      if (listening) {
        recognition.stop();
        return;
      }
      recognition.lang = (langSelect && langSelect.value) || "en-US";
      listening = true;
      voiceBtn.textContent = "⏹ Stop";
      setTyping("Listening (" + (recognition.lang || "en-US") + ")…");
      try {
        recognition.start();
      } catch (_) {
        listening = false;
        voiceBtn.textContent = "🎤 Speak";
      }
    });
  }

  if (locateBtn) {
    locateBtn.addEventListener("click", () => {
    if (!navigator.geolocation) {
      appendMessage("bot", "Geolocation is not available in this browser.");
      return;
    }
    setTyping("Getting location…");
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        ensureMap(lat, lng);
        try {
          const data = await postJson("/get_location_hospitals", { lat, lng });
          await handleChatResponse(data);
        } catch (e) {
          appendMessage("bot", "Location lookup failed: " + e.message);
        } finally {
          setTyping("");
        }
      },
      () => {
        setTyping("");
        appendMessage(
          "bot",
          "Could not read your location. Allow location access or type a city in chat after choosing hospitals."
        );
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
  });
  }

  async function initChat() {
    setTyping("Loading…");
    lastStep = "symptoms";
    if (seasonSelect) seasonSelect.value = "auto";
    try {
      const data = await postJson("/chat", { message: "__init__" });
      await handleChatResponse(data);
    } catch (e) {
      appendMessage("bot", "Could not reach server. Is Flask running on port 5000?");
    } finally {
      setTyping("");
    }
    if (window.L) {
      ensureMap(20.5937, 78.9629);
      map.setZoom(5);
    }
  }

  setupRecognition();
  initChat();
})();
